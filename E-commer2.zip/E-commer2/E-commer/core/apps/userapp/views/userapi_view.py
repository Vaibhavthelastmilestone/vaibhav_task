# from django.contrib.auth import authenticate, login
# from django.contrib.auth.hashers import make_password
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from apps.userapp.models import Tbl_User_Auth

# class RegistrationAPI(APIView):
#     def post(self, request):
#         email = request.data.get('email')
#         password = request.data.get('password')
#         # Check if user already exists
#         if Tbl_User_Auth.objects.filter(email=email).exists():
#             return Response({'error': 'User already exists'}, status=status.HTTP_400_BAD_REQUEST)

#         # Create a new user
#         Tbl_User_Auth.objects.create(email=email, password=password)
       
#         return Response({'message': 'User registered successfully'}, status=status.HTTP_201_CREATED)

# class LoginAPI(APIView):
#     def post(self, request):
#         # Check if email and password are present in the request data
#         if 'email' not in request.data or 'password' not in request.data:
#             return Response({'error': 'Email and password are required'}, status=status.HTTP_400_BAD_REQUEST)
        
#         email = request.data['email']
#         password = request.data['password']

#         # Authenticate user
#         user = authenticate(email=email, password=password)

#         if user is not None:
#             if user.is_active:
#                 # Login the user
#                 login(request, user)
#                 return Response({'message': 'Login successful'})
            
#             else:
#                 return Response({'error': 'User account is disabled'}, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)
