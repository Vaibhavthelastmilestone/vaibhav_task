from django.urls import path
from apps.userapp.views.view_admin import *
from apps.userapp.views.userapi_view import *

urlpatterns = [
  
    path("",login ,name='login'),
    path("index",index ,name='index'),


#API
    # path('register/',RegistrationAPI.as_view(), name='register_user'),
    # path('login/', LoginAPI.as_view(), name='login_user'),
]
