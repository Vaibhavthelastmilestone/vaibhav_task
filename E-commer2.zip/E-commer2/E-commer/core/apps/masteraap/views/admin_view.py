from django.shortcuts import render,redirect
# from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from apps.masteraap.models import *
from django.shortcuts import get_object_or_404
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views import View
from django.db.models import Q




class CategoryView(View):
    def get(self, request, id=None):
        if id:
            category = Category.objects.get(id=id)
            category.delete()
            messages.success(request, 'A Category is deleted successfully.')
            return redirect('/category')
            
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                data = Category.objects.filter(name__icontains=searchobj)
            else:
                data = Category.objects.all()

            page_number = request.GET.get('page', 1)
            paginator = Paginator(data, 5)
            try:
                data = paginator.page(page_number)
            except PageNotAnInteger:
                data = paginator.page(1)
            except EmptyPage:
                data = []

            if "q" in request.GET:
                context = {'data': data, 'q': request.GET.get("q")}
            else:
                context = {'data': data}

            return render(request, 'category.html', context)

    def post(self, request, id=None):
        if id:
            category = get_object_or_404(Category, pk=id)
            if 'status_update' in request.POST: 
                category.is_active = not category.is_active
                category.save()
                messages.success(request, 'A Category status updated successfully.')
                return redirect('/category')
            
            category_name = request.POST.get('category_name')
            if category.category_name != category_name:
                category.category_name = category_name
                category.save()
                messages.success(request, 'Category information updated successfully.')            
            return redirect('/category')

        else:
            category_name = request.POST.get('category_name')
            if Category.objects.filter(category_name=category_name).exists():
                messages.error(request, 'A Category with the same name already exists.')
                return redirect('/category') 
            else:
                try:
                    category = Category(category_name=category_name)
                    category.save()
                    messages.success(request, 'A Category Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the category.')
            return redirect('/category')

class SubcategoryView(View):
    def get(self, request, id=None):
        if id:
            subcategory = get_object_or_404(SubCategory, pk=id)
            subcategory.delete()
            messages.success(request, 'A Subcategory is deleted successfully.')
            return redirect('/subcategory')
            
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                data = SubCategory.objects.filter(subCategoryName__icontains=searchobj)
            else:
                data = SubCategory.objects.all()

            # Pagination
            page_number = request.GET.get("page", 1)
            paginatorobj = Paginator(data, 10)
            try:
                data = paginatorobj.page(page_number)
            except PageNotAnInteger:
                data = paginatorobj.page(1)
            except EmptyPage:
                data = paginatorobj.page(paginatorobj.num_pages)

            maincatobj = Category.objects.all()
            return render(request, 'sub_category.html', {'data': data, 'maincatobj':maincatobj})


    def post(self, request, id=None):
        if id:
            subcategory =SubCategory.objects.get(id=id)
            if 'status_update' in request.POST: 
                subcategory.is_active = not subcategory.is_active
                subcategory.save()
                messages.success(request, 'A Subcategory status updated successfully.')
                return redirect('/subcategory')
            
            subcategory_name = request.POST.get('subcategory_name')

            # Retrieve the existing subcategory object from the database
            subcategory =SubCategory.objects.get(id=id)
                
            if subcategory.subcategory_name != subcategory_name:
                subcategory.subcategory_name = subcategory_name
                subcategory.save()
                messages.success(request, 'Subcategory information updated successfully.')            
            return redirect('/subcategory')

        else:
            main_category_id = request.POST.get('category_id')
            main_category = Category.objects.get(id=main_category_id)

            subcategory_name = request.POST['subcategory_name']
            if SubCategory.objects.filter(subcategory_name=subcategory_name, category=main_category).exists():
                messages.error(request, 'A Subcategory with the same name already exists for this main category.')
                return redirect('/subcategory') 
            else:
                try:
                    subcategory = SubCategory(subcategory_name=subcategory_name, category=main_category)
                    subcategory.save()
                    messages.success(request, 'A Subcategory Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the subcategory.')
            return redirect('/subcategory')
        
        


class ProductView(View):
    def get(self, request, id=None):
        if id:
            # If an ID is provided, it means we're deleting the product
            product = get_object_or_404(Product, pk=id)
            product.delete()
            messages.success(request, 'A Product is deleted successfully.')
            return redirect('/product')
        else:
            # If no ID is provided, it means we're displaying all products
            products = Product.objects.all()
            # productimg = ProductImage.objects.all()

            # Implementing search functionality
            search_query = request.GET.get('q')
            if search_query:
                products = products.filter(Q(productname__icontains=search_query))

            # Implementing pagination
            paginator = Paginator(products, 5)  # Show 5 products per page
            page_number = request.GET.get('page')
            try:
                products = paginator.page(page_number)
            except PageNotAnInteger:
                products = paginator.page(1)
            except EmptyPage:
                products = paginator.page(paginator.num_pages)

            mainobj = Category.objects.all()
            subobj = SubCategory.objects.all()

            context = {
                'products': products,
                "mainobj": mainobj,
                "subobj": subobj,
                # 'productimg': productimg
            }

            return render(request, 'product.html', context)

    def post(self, request, id=None):
        if id:
            # If an ID is provided, it means we're updating an existing product
            product = Product.objects.get(id=id)
            product_name = request.POST.get('product_name')
            product_price = request.POST.get('product_price')
            product_description = request.POST.get('product_description')
            image = request.FILES.POST('image')

            # Update product information
            product.product_name = product_name
            product.product_price = product_price
            product.product_description = product_description
            product.image = image
            product.save()


            # Handle Product Images
               

            messages.success(request, 'Product information updated successfully.')
            return redirect('/product')
        else:
            # try:
                # Retrieve form data
                category_id = request.POST.get('category')
                subcategory_id = request.POST.get('subcategory')
                product_name = request.POST.get('product_name')
                product_price = request.POST.get('product_price')
                product_description = request.POST.get('product_description')
                images = request.FILES.getlist('product_images')

                # Check if a product with the same name already exists
                if Product.objects.filter(product_name=product_name).exists():
                    messages.error(request, 'A Product with the same name already exists.')
                    return redirect('/product')

                # Convert category, subcategory, sub_subcategory, and brand IDs to instances
                category = Category.objects.get(pk=category_id)
                subcategory = SubCategory.objects.get(pk=subcategory_id)

                # Create a new product
                product = Product(
                    category=category,
                    subcategory=subcategory,
                    product_name=product_name,
                    product_price=product_price,
                    product_description=product_description,
                    image=image
                )
                product.save()


                # Handle Product Images
               

                messages.success(request, 'A Product Created Successfully.')
            # except Exception as e:
                # print(f"Error occurred: {e}")
                # messages.error(request, 'An error occurred while creating the product.')

                return redirect('/product')
