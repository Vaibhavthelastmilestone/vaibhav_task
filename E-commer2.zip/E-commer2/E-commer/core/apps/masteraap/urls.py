from django.urls import path
from apps.masteraap.views.admin_api import *
from apps.masteraap.views.admin_view import *

urlpatterns = [
  
    # path("",login ,name='login'),
    # path("index",index ,name='index'),
    

    path('category/',CategoryView.as_view(), name='category'),
    path('category/<int:id>/',CategoryView.as_view(), name='category'),

    path('subcategory/',SubcategoryView.as_view(), name='subcategory'),
    path('subcategory/<int:id>/',SubcategoryView.as_view(), name='subcategory'),

    path('product/',ProductView.as_view(), name='product'),
    path('product/<int:id>/',ProductView.as_view(), name='product'),


    path('CategoryMasterAPI/', CategoryMasterAPI.as_view(), name='category_master_api'),
    path('SubCategoryMasterAPI/', SubCategoryMasterAPI.as_view(), name='subcategory_master_api'),
    path('ProductMasterAPI/', ProductMasterAPI.as_view(), name='product_master_api'),
    path('ReviewProductMasterAPI/', ReviewProductMasterAPI.as_view(), name='review_product_master_api'),
    path('ProductImageMasterAPI/', ProductImageMasterAPI.as_view(), name='product_image_master_api'),
]

