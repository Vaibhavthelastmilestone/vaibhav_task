from django.db import models
from apps.masteraap.basecontent import BaseContent
from apps.userapp.models import Tbl_User_Auth
from django.utils import timezone

class Category(BaseContent):
    category_name = models.CharField(max_length=255, unique=True)
    display_list = ['id', 'category_name']
    searchable_fields = ['id', 'category_name']
    
    class Meta:
        db_table ='masterapp_MainCategory'

    def __str__(self):
        return self.category_name
    
class SubCategory(BaseContent):
    subcategory_name = models.CharField(max_length=255, unique=True) 
    category = models.ForeignKey(to=Category, on_delete=models.CASCADE)
    display_list = ['id', 'category', 'category_id', "subcategory_name"]
    searchable_fields = ['id', 'subcategory_name']
    
    class Meta:
        db_table ='masterapp_SubCategory'

    def __str__(self):
        return self.subcategory_name 

class Product(BaseContent):
    category = models.ForeignKey(to=Category, on_delete=models.CASCADE)
    subcategory = models.ForeignKey(to=SubCategory, on_delete=models.CASCADE)
    product_name = models.CharField(max_length=255, unique=True)
    product_price = models.CharField(max_length=255)
    product_description = models.TextField()
    image = models.ImageField(upload_to='product_images')
    user = models.ForeignKey(Tbl_User_Auth, on_delete=models.CASCADE, related_name='products', null=True, blank=True)

    display_list = ['id', 'category', 'category_id', "subcategory", "subcategory_id", "product_name", "product_price", "product_description"]
    searchable_fields = ['id', 'product_name']
    
    class Meta:
        db_table ='masterapp_Product'

    def __str__(self):
        return self.product_name

    
class Like(models.Model):
    user = models.ForeignKey(Tbl_User_Auth, on_delete=models.CASCADE, related_name='likes')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='likes')

    class Meta:
        unique_together = ('user', 'product')

class Rating(models.Model):
    user = models.ForeignKey(Tbl_User_Auth, on_delete=models.CASCADE, related_name='ratings')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='ratings')
    rating = models.IntegerField(choices=((1, '1'), (2, '2'), (3, '3'), (4, '4'), (5, '5')))
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'product')



class ProductImage(models.Model):
    product = models.ForeignKey(to=Product,on_delete=models.CASCADE)
    product_image = models.ImageField(upload_to='Product Image',blank=True,null=True)
    # is_active = models.BooleanField(default=True)
    


class ReviewProduct(models.Model):
    product = models.ForeignKey(to=Product,on_delete=models.CASCADE)
    rating = models.PositiveIntegerField()
    comment = models.TextField(blank=True,null=True,default=True)
    created_at = models.DateTimeField(auto_now_add=True)
